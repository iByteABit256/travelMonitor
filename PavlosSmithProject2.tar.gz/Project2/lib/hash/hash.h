unsigned long hash_i(unsigned char *str, unsigned int i);

